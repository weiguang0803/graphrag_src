"""
GraphRAG 前端配套后端（FastAPI）

功能：
- 提供 POST /api/query 接口，接收 { question, method }
- 调用 `graphrag query --root <GRAPHRAG_ROOT> --method <method> "<question>"`
- 解析输出，返回 { answer: "..." }

使用：
    pip install fastapi uvicorn pydantic
    # 将下方 GRAPHRAG_ROOT 改为你的 graphrag 项目根目录（含 settings.yaml / output/）
    uvicorn backend:app --host 127.0.0.1 --port 8000 --reload

前端开发服务器（Vite）默认代理 /api -> http://127.0.0.1:8000
"""
import subprocess
import re
from typing import Optional
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware

# ===== 需要你修改的路径 =====
GRAPHRAG_ROOT = r"C:\Users\15922\Desktop\llm\graphrag\graphrag_src"
GRAPHRAG_BIN = "graphrag"  # 若用 uv，可改为 ["uv", "run", "poe", "query", "--root", GRAPHRAG_ROOT, "--method"]
# ===========================

app = FastAPI(title="GraphRAG Web API")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


class QueryRequest(BaseModel):
    question: str
    method: str = "local"  # local / global / drift / basic


def parse_answer(raw: str) -> str:
    """从 graphrag query 的原始输出中提取最终回答。
    graphrag 输出通常含日志行，回答在最后；这里取最后一个非空段落。"""
    if not raw:
        return ""
    # 去掉 ANSI 颜色码
    raw = re.sub(r"\x1b\[[0-9;]*m", "", raw)
    parts = re.split(r"(?:\n\s*){2,}", raw.strip())
    parts = [p.strip() for p in parts if p.strip()]
    if not parts:
        return raw.strip()
    # 优先返回包含中文/较长的一段
    parts.sort(key=lambda s: len(s), reverse=True)
    return parts[0]


@app.post("/api/query")
def query(req: QueryRequest):
    if req.method not in {"local", "global", "drift", "basic"}:
        raise HTTPException(status_code=400, detail="method 必须是 local/global/drift/basic")

    cmd = [
        GRAPHRAG_BIN, "query", "--root", GRAPHRAG_ROOT,
        "--method", req.method, req.question,
    ]
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
    except FileNotFoundError:
        raise HTTPException(
            status_code=500,
            detail=f"未找到 {GRAPHRAG_BIN} 命令，请确认 GraphRAG 已安装并在 PATH 中",
        )
    except subprocess.TimeoutExpired:
        raise HTTPException(status_code=504, detail="查询超时（>300s）")

    if proc.returncode != 0:
        raise HTTPException(
            status_code=500,
            detail=f"graphrag 执行失败：{proc.stderr.strip() or proc.stdout.strip()}",
        )

    answer = parse_answer(proc.stdout)
    return {"answer": answer, "method": req.method}


@app.get("/api/health")
def health():
    return {"status": "ok"}
